#!/bin/bash

npm run dev