import React from 'react'
import Link from 'next/link'
import style from '@/styles/components/general/Button.module.scss'
import Triangle from './Triangle'

interface ButtonProps {
  title: string,
  linkTo?: string,
  onClick?: () => void,
}

const Button = (props: ButtonProps) => {
  const onClick = () => {
    const onClickProp = props.onClick
    if (onClickProp == null || onClickProp == undefined) return
    onClickProp();
  }

  const triangle = (
    <Triangle
      white={true}
      size={5} />
  )
  if (props.onClick != null) {
    return (
      <button
        className={style.btn}
        onClick={onClick}>
        {triangle}
        {props.title}
      </button>
    )
  }
  return (
    <Link
      className={style.btn}
      href={props.linkTo ?? '/'}>
      {triangle}
      {props.title}
    </Link>
  )
}


export default Button